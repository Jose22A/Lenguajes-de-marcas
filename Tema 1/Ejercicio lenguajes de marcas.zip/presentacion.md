# Jose Alberto Soto Mas
## Torremolinos
### Mis comidas favoritas
- Pizza
- Hamburguesa
- Sandwich
### Enlace de interés
[Visita mi página favorita](https://iesplayamar.es/)
### Imagen que me gusta
![Texto alternativo](https://ruta-de-la-imagen.com/imagen.jpg)